package excepciones;


@SuppressWarnings("serial")
public class DivisionPorCeroException extends Exception{

	
}
