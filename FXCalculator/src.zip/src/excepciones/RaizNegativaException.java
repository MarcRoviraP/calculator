package excepciones;

@SuppressWarnings("serial")
public class RaizNegativaException extends Exception{

}
